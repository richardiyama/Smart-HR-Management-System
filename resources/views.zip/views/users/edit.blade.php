@extends('layouts.dash')

@section('content')
@include('inc.editUser')
@endsection