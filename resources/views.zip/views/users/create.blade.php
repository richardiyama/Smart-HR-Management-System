@extends('layouts.dash')

@section('content')
    @include('inc.addUser')
@endsection