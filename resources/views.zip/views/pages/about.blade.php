@extends('layouts.app')
@section('content')
        <h1>About Page</h1>
        <p>this is about page</p>
@endsection
